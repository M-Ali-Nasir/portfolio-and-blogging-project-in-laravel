<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unsubscribe Confirmation</title>
</head>
<body>
    <p>Hello {{ $userName }},</p>
    <p>You have successfully unsubscribed from our Blog Updates.</p>
    <p>If this was a mistake, you can re-subscribe at any time.</p>
    <p>Thank you!</p>
</body>
</html>